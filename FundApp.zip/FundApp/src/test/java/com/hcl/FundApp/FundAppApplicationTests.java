package com.hcl.FundApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FundAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
